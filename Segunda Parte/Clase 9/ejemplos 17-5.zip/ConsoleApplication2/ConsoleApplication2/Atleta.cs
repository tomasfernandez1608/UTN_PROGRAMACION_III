﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Atleta: IComparable, IEquatable<Atleta>
    {
        int numero, mejorTiempo;
        string nombre, apellido;

        public Atleta(int numero, int mejorTiempo, string nombre, string apellido)
        {
            this.numero = numero;
            this.mejorTiempo = mejorTiempo;
            this.nombre = nombre;
            this.apellido = apellido;
        }
        public Atleta(int numero)
        {
            this.numero = numero;
        }


        public int CompareTo(object obj)
        {
            if (obj is Atleta)
            {
                Atleta n = (Atleta)obj;
                if (this.mejorTiempo > n.mejorTiempo) return 1;
                if (this.mejorTiempo < n.mejorTiempo) return -1;
                return 0;
            }
            else
            {
                return int.MaxValue;
            }
        }



        public bool Equals(Atleta other)
        {
            if (other.numero == this.numero)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string darDatos()
        {
            return nombre.ToString() + apellido.ToString() + numero.ToString() + mejorTiempo.ToString();
        }
    }
}
