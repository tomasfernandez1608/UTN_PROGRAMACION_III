﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Atleta> lista = new List<Atleta>();
            lista.Add(new Atleta(123,20,"tito","jackson"));
            lista.Add(new Atleta(2333,-3,"jose","pekerman"));
            lista.Add(new Atleta(43434,1,"usain","bolt"));

            lista.Sort();
            foreach(Atleta elemento in lista){
                Console.WriteLine(elemento.darDatos());
            }
            int indice = lista.IndexOf(new Atleta(123));

            Console.ReadLine();


        }

    }
}
