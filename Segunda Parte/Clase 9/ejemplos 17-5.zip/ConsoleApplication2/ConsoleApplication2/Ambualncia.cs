﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Ambualncia:IAlarma
    {
                string marca;
        string patente;

        public Ambualncia(string marca, string patente)
        {
            this.marca = marca;
            this.patente = patente;
        }


        public string darAlarma(int repeticiones)
        {
            string rta = "";
            for (int i = 0; i < repeticiones; i++)
            {
                rta += "ninu ninu ";
            }
            return rta;
        }
    }
}
