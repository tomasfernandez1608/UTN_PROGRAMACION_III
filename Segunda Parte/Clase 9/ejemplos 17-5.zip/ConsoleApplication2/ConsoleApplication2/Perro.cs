﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Perro: IAlarma, IEquatable<Perro>
    {
        string nombre;
        string raza;

        public Perro(string nombre, string raza)
        {
            this.nombre = nombre;
            this.raza = raza;
        }


        public string darAlarma(int repeticiones)
        {
            string rta = "";
            for (int i = 0; i < repeticiones; i++)
            {
                rta += "guau ";
            }
            return rta;
        }
        public string darDatos()
        {
            return this.nombre + " " + this.raza;
        }

        public bool Equals(Perro other)
        {
            if (this.nombre == other.nombre)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

}
