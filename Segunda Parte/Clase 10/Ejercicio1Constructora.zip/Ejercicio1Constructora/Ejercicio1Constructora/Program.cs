﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1Constructora
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno.Cuota = Interfaz.devolverFloat("Ingrese la cuota del alumno");
            Profesor.SalarioBasico = Interfaz.devolverFloat("Ingrese el salario del profesor");
            List<Alumno> alumnos = new List<Alumno>();
            List<Profesor> profesores = new List<Profesor>();
            uint legajo = Interfaz.devolverUInt("Ingrese el legajo del alumno, 0 para finalizar");
            string nombre, apellido, email;
            int antiguedad;
            float porcBeca;
            while (legajo > 0)
            {
                nombre = Interfaz.devolverString("Ingrese el nombre del alumno");
                apellido = Interfaz.devolverString("Ingrese el apellido del alumno");
                email = Interfaz.devolverString("Ingrese el email del alumno");
                porcBeca = Interfaz.devolverFloat("Ingrese el porcentaje de beca del alumno");
                alumnos.Add(new Alumno(legajo, nombre, apellido, email, porcBeca));
                legajo = Interfaz.devolverUInt("Ingrese el legajo del alumno, 0 para finalizar");
            }
            Interfaz.mostrarMensaje("Ingreso de alumnos finalizado");
            legajo = Interfaz.devolverUInt("Ingrese el legajo del profesor, 0 para finalizar");
            while (legajo > 0)
            {
                nombre = Interfaz.devolverString("Ingrese el nombre del profesor");
                apellido = Interfaz.devolverString("Ingrese el apellido del profesor");
                email = Interfaz.devolverString("Ingrese el email del profesor");
                antiguedad = Interfaz.devolverInt("Ingrese la antiguedad del profesor");
                profesores.Add(new Profesor(antiguedad, legajo, nombre, apellido, email));
                legajo = Interfaz.devolverUInt("Ingrese el legajo del profesor, 0 para finalizar");
            }
            Interfaz.mostrarMensaje("Ingreso de profesores finalizado");
            Interfaz.mostrarMensaje("mostrando alumnos ordenados");
            alumnos.Sort();
            foreach(Alumno alumno in alumnos)
            {
                Interfaz.mostrarMensaje(alumno.mostrarDatos());
            }
            Interfaz.mostrarMensaje("mostrando profesores ordenados");
            profesores.Sort();
            foreach(Profesor profesor in profesores)
            {
                Interfaz.mostrarMensaje(profesor.mostrarDatos());
            }
            Interfaz.devolverString("Hasta luego");

        }
    }
}
