﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1Constructora
{
    static class Interfaz
    {
        public static int devolverInt(string mensaje)
        {
            mostrarMensaje(mensaje);
            return int.Parse(Console.ReadLine());
        }

        public static void mostrarMensaje(string mensaje)
        {
            Console.WriteLine(mensaje);
        }
        public static float devolverFloat(string mensaje)
        {
            mostrarMensaje(mensaje);
            return float.Parse(Console.ReadLine());
        }
        public static string devolverString(string mensaje)
        {
            mostrarMensaje(mensaje);
            return Console.ReadLine();
        }
        public static uint devolverUInt(string mensaje)
        {
            mostrarMensaje(mensaje);
            return Convert.ToUInt32(Console.ReadLine());
        }
    }
}
