﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1Constructora
{
    class Profesor:Persona, IComparable
    {
        static float salarioBasico;
        int antiguedad;

        public static float SalarioBasico { get => salarioBasico; set => salarioBasico = value; }
        public int Antiguedad { get => antiguedad; set => antiguedad = value; }

        public Profesor(int antiguedad, uint legajo,string nombre, string apellido,string email ):base(legajo,nombre,apellido,email)
        {
            this.antiguedad = antiguedad;
        }
        public Profesor(uint legajo) : base(legajo)
        {
            antiguedad = 0;
        }
        public float calcularSalario()
        {
            return salarioBasico + salarioBasico * antiguedad * (0.03f);
        }
        public override string mostrarDatos()
        {
            string rta = "Datos del Profesor: \n" + "Antiguedad: " + antiguedad +" "+ base.mostrarDatos();
            return rta;
        }

        public int CompareTo(object obj)
        {
            if(obj is Profesor)
            {
                Profesor profesor = (Profesor)obj;
                if (this.calcularSalario() > profesor.calcularSalario()) return 1;
                if (this.calcularSalario() < profesor.calcularSalario()) return -1;
                if (this.calcularSalario() == profesor.calcularSalario()) return 0;
            }
            return int.MaxValue;
        }
    }
}
