﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1Constructora
{
    class Alumno : Persona, IComparable
    {
        float porcBeca;
        static float cuota;

        public static float Cuota { get => cuota; set => cuota = value/100; }
        public float PorcBeca { get => porcBeca; set => porcBeca = value; }

        public Alumno(uint legajo, string nombre, string apellido, string email, float porcentaje) : base(legajo, nombre, apellido, email)
        {
            this.porcBeca = porcentaje/100;
        }
        public Alumno(uint legajo) : base(legajo)
        {
            this.porcBeca = 0;
        }
        public float calcularCuota()
        {
            return cuota - cuota * porcBeca;
        }


        public override string mostrarDatos()
        {
            string rta = "Datos del alumno: \n" + "porcentaje de beca: " + porcBeca + " " + base.mostrarDatos();
            return rta;
        }

        public int CompareTo(object obj)
        {
             if (obj is Alumno)
            {
                Alumno otro = (Alumno)obj;
                if (otro.calcularCuota() < this.calcularCuota()) return -1;
                if (otro.calcularCuota() > this.calcularCuota()) return 1;
                if (otro.calcularCuota() == this.calcularCuota()) return 0;
            }
            return int.MaxValue;
        }
    }
}
