﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1Constructora
{
    class Persona:IEquatable<Persona>
    {
        uint legajo;
        string nombre, apellido, email;

        public uint Legajo { get => legajo; set => legajo = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Email { get => email; set => email = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public Persona(uint legajo, string nombre, string apellido, string email)
        {
            this.legajo = legajo;
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Email = email;
        }

        public Persona(uint legajo)
        {
            this.legajo = legajo;
        }


        public bool Equals(Persona other)
        {
            if (this.Legajo == other.Legajo) return true;
            return false;
        }

        public virtual string mostrarDatos()
        {
            return "Legajo: " + legajo + " nombre y apellido: " + nombre + " " + apellido + " email: " + email;
        }
    }
}
