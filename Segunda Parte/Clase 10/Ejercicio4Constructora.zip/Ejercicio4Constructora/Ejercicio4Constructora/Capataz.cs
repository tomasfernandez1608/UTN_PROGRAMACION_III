﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4Constructora
{
    class Capataz:Empleado
    {
        uint matricula;
        
        public uint getMatricula()
        {
            return this.matricula;
        }
        public void setMatricula(uint matricula)
        {
            this.matricula = matricula;
        }

        public Capataz(uint matricula, string nombre, string apellido, string dni): base(dni, apellido, nombre)
        {
            this.matricula = matricula;
        }
        public Capataz(string dni) : base(dni)
        {
            this.matricula = 000;
        }
        public override string mostrarDatos()
        {
            string rta = "Tipo de empleado: Capataz \n" + "matricula: " + this.matricula + "\n" + base.mostrarDatos();
            return rta;
        }
    }
}
