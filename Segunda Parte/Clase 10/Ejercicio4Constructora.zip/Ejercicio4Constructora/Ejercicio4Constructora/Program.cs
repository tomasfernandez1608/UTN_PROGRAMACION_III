﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4Constructora
{
    class Program
    {
        static void Main(string[] args)
        {
            ControladorEmpleados listaEmpleados = new ControladorEmpleados();
            Interfaz.mostrarMenu();
            int opcion = Interfaz.devolverInt("Su opcion: ");
            string nombre, apellido, dni, especialidad;
            uint matricula;
            do {
                switch (opcion)
                {
                    case 1:
                        Interfaz.mostrarMensaje(listaEmpleados.listarEmpleados());
                        Interfaz.limpiar();
                        break;
                    case 2:
                        dni = Interfaz.devolverString("Ingrese el DNI");
                        nombre = Interfaz.devolverString("Ingrese el nombre");
                        apellido = Interfaz.devolverString("Ingrese apellido");
                        especialidad = Interfaz.devolverString("Ingrese especialidad");
                        if (listaEmpleados.agregarObrero(dni, nombre, apellido, especialidad))
                        {
                            Interfaz.mostrarMensaje("Agregado!");
                        }
                        else
                        {
                            Interfaz.mostrarMensaje("Fallo");
                        }
                        Interfaz.limpiar();
                        break;
                    case 3:
                        dni = Interfaz.devolverString("Ingrese el DNI");
                        nombre = Interfaz.devolverString("Ingrese el nombre");
                        apellido = Interfaz.devolverString("Ingrese apellido");
                        matricula = Interfaz.devolverUInt("Ingrese la matricula");
                        if (listaEmpleados.agregarCapataz(dni, nombre, apellido, matricula))
                        {
                            Interfaz.mostrarMensaje("Agregado!");
                        }
                        else
                        {
                            Interfaz.mostrarMensaje("Fallo");
                        }
                        Interfaz.limpiar();
                        break;
                    case 4:
                        dni = Interfaz.devolverString("Ingrese el DNI");
                        if (listaEmpleados.eliminarEmpleado(dni))
                        {
                            Interfaz.mostrarMensaje("Exito");
                        }
                        else
                        {
                            Interfaz.mostrarMensaje("Fallo");
                        }
                        Interfaz.limpiar();
                        break;
                    case 5:
                        dni = Interfaz.devolverString("Ingrese el DNI");
                        nombre = Interfaz.devolverString("Ingrese el nombre");
                        apellido = Interfaz.devolverString("Ingrese apellido");
                        especialidad = Interfaz.devolverString("Ingrese especialidad");
                        if (listaEmpleados.editarObrero(dni, nombre, apellido, especialidad)){
                            Interfaz.mostrarMensaje("Editado!");
                        }
                        else
                        {
                            Interfaz.mostrarMensaje("Fallo");
                        }
                        Interfaz.limpiar();
                        break;
                    case 6:
                        dni = Interfaz.devolverString("Ingrese el DNI");
                        nombre = Interfaz.devolverString("Ingrese el nombre");
                        apellido = Interfaz.devolverString("Ingrese apellido");
                        matricula = Interfaz.devolverUInt("Ingrese la matricula");
                        if (listaEmpleados.editarCapataz(dni, nombre, apellido, matricula))
                        {
                            Interfaz.mostrarMensaje("Editado");
                        }
                        else
                        {
                            Interfaz.mostrarMensaje("Fallo");
                        }
                        Interfaz.limpiar();
                        break;
                    case 7:
                        Interfaz.mostrarMensaje("Hasta luego");
                        break;
                    default:
                        Interfaz.mostrarMensaje("Ingrese una opcion valida");
                        break;

                }
                Interfaz.mostrarMenu();
                opcion = Interfaz.devolverInt("Su opcion: ");
            }
            while (opcion!=7);
            Interfaz.devolverString("Presione enter para salir");
        }
    }
}
