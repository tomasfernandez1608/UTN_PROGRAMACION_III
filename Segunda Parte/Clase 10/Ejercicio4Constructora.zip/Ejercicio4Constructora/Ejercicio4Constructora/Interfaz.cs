﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4Constructora
{
    static class Interfaz
    {
        public static int devolverInt(string mensaje)
        {
            mostrarMensaje(mensaje);
            return int.Parse(Console.ReadLine());
        }

        public static void mostrarMensaje(string mensaje)
        {
            Console.WriteLine(mensaje);
        }
        public static float devolverFloat(string mensaje)
        {
            mostrarMensaje(mensaje);
            return float.Parse(Console.ReadLine());
        }
        public static string devolverString(string mensaje)
        {
            mostrarMensaje(mensaje);
            return Console.ReadLine();
        }
        public static uint devolverUInt(string mensaje)
        {
            mostrarMensaje(mensaje);
            return Convert.ToUInt32(Console.ReadLine());
        }
        public static void mostrarMenu()
        {
            Console.WriteLine("Aplicacion Consturctora");
            Console.WriteLine("Ingrese una opcion");
            Console.WriteLine("1- Listar obreros y capataces registrados");
            Console.WriteLine("2- Agregar un obrero");
            Console.WriteLine("3- Agregar un capataz");
            Console.WriteLine("4- Remover a un obrero o capataz");
            Console.WriteLine("5- Editar un obrero");
            Console.WriteLine("6- Editar un capataz");
            Console.WriteLine("7- Salir");
        }
        public static void limpiar()
        {
            Console.ReadLine();
            Console.Clear();
        }
    }
}
