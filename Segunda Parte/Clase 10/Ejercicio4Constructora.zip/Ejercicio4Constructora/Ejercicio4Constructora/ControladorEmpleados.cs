﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4Constructora
{
    class ControladorEmpleados
    {
        List<Empleado> empleados;

        public ControladorEmpleados()
        {
            this.empleados = new List<Empleado>();
        }

        public Empleado buscar(string dni)
        {
            int indice = empleados.IndexOf(new Empleado(dni));
            if (indice >= 0)
            {
                return empleados[indice];
            }
            else
            {
                return null;
            }
        }

        public bool agregarObrero(string dni, string nombre, string apellido, string especialidad)
        {
            Empleado aux = buscar(dni);
            if (aux == null)
            {
                Obrero nuevo = new Obrero(especialidad, nombre, apellido, dni);
                empleados.Add(nuevo);
                Console.WriteLine(nuevo.mostrarDatos());
                return true;
            }
            return false;
        }
        public bool agregarCapataz(string dni, string nombre, string apellido, uint matricula)
        {
            Empleado aux = buscar(dni);
            if (aux == null)
            {
                Capataz nuevo = new Capataz(matricula, nombre, apellido, dni);
                empleados.Add(nuevo);
                Console.WriteLine(nuevo.mostrarDatos());
                return true;
            }
            return false;
        }
        public bool eliminarEmpleado(string dni)
        {
            Empleado aux = buscar(dni);
            if (aux != null)
            {
                empleados.Remove(aux);
                return true;
            }
            return false;
        }
        public bool editarObrero(string dni, string nombre, string apellido, string especialidad)
        {
            Obrero aux = (Obrero)buscar(dni);
            if (aux != null)
            {
                aux.setApellido(apellido);
                aux.setDNI(dni);
                aux.setEspecialidad(especialidad);
                aux.setNombre(nombre);
                return true;
            }
            return false;
        }
        public bool editarCapataz(string dni, string nombre, string apellido, uint matricula)
        {
            Capataz aux = (Capataz)buscar(dni);
            if (aux != null)
            {
                aux.setApellido(apellido);
                aux.setDNI(dni);
                aux.setMatricula(matricula);
                aux.setNombre(nombre);
                return true;
            }
            return false;
        }
        public string listarEmpleados()
        {
            string rta = "";
            foreach(Empleado empleado in empleados)
            {
                if (empleado is Obrero)
                {
                    Obrero obrero = (Obrero)empleado;
                    rta += obrero.mostrarDatos();
                }
                else
                {
                    if (empleado is Capataz)
                    {
                        Capataz capataz = (Capataz)empleado;
                        rta += capataz.mostrarDatos();
                    }
                    else
                    {
                        rta += empleado.mostrarDatos();
                    }
                }
            }
            return rta;
        }
    }
}
