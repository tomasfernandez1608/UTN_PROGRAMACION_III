﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4Constructora
{
    class Obrero: Empleado
    {
        string especialidad;

        public Obrero(string especialidad, string nombre, string apellido, string dni):base(dni,apellido,nombre)
        {
            this.especialidad = especialidad;
        }
        public Obrero(string DNI) : base(DNI)
        {
            this.especialidad = "";
        }
        public string getEspecialidad()
        {
            return this.especialidad;
        }
        public void setEspecialidad(string especialidad)
        {
            this.especialidad = especialidad;
        }
        public override string mostrarDatos()
        {
            string rta = "Tipo de empleado: Obrero \n" + "especialidad: " + this.especialidad + "\n" + base.mostrarDatos();
            return rta;
        }
    }
}
