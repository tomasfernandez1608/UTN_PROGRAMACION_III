﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4Constructora
{
    class Empleado: IEquatable<Empleado>
    {
        string DNI, apellido, nombre;

        public Empleado(string dNI, string apellido, string nombre)
        {
            DNI = dNI;
            this.apellido = apellido;
            this.nombre = nombre;
        }

        public Empleado(string dni)
        {
            DNI = dni;
        }

        public string getDNI()
        {
            return this.DNI;
        }
        public string getApellido()
        {
            return this.apellido;
        }
        public string getNombre()
        {
            return this.nombre;
        }
        public void setDNI(string DNI)
        {
            this.DNI = DNI;
        }
        public void setApellido(string apellido)
        {
            this.apellido = apellido;
        }
        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public bool Equals(Empleado other)
        {
            return this.DNI == other.DNI;
        }
        public virtual string mostrarDatos()
        {
            return "DNI: " + DNI + " nombre: " + nombre + " apellido: " + apellido + "\n";
        }
    }
}
