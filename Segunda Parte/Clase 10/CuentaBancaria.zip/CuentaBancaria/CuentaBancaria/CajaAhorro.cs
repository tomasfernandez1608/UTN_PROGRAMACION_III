﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_bancariaBien
{
    class CajaAhorro:Cuenta
    {
        static float interesRetorno;
        string planCuenta;
        ulong tarjetaVinculada;
        public static void setInteres(float interes)
        {
            CajaAhorro.interesRetorno = interes/100;
        }
        public static float getInteres()
        {
            return CajaAhorro.interesRetorno;
        }
        public CajaAhorro():base()
        {
            this.planCuenta = "basico";
            this.tarjetaVinculada = 0000;
        }

        public CajaAhorro(string planCuenta, ulong tarjetaVinculada, ulong CBU, string cliente, float saldo) :base(CBU,cliente,saldo)
        {
            this.planCuenta = planCuenta;
            this.tarjetaVinculada = tarjetaVinculada;
        }

        public override string darDatos()
        {
            return "Tipo de cuenta: Caja de ahorro" + base.darDatos() + " plan: " + this.planCuenta + " tarjeta: " + this.tarjetaVinculada.ToString();
        }
        public float simularIntereses(int meses)
        {
            return getSaldo() + CajaAhorro.interesRetorno * getSaldo() * meses;
        }


    }
}


