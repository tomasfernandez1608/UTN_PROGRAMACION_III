﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_bancariaBien
{
    internal class CtaCorriente:Cuenta
    {
        float interesDescubierto;
        private static float montoDescubierto;

        public static float MontoDescubierto { get => montoDescubierto; set => montoDescubierto = value; }

        public float getDescubierto()
        {
            return this.interesDescubierto;
        }
        public void setDescubierto(float interes)
        {
            this.interesDescubierto = interes/100;
        }

        public CtaCorriente(float interesDescubierto, ulong CBU, string cliente, float saldo):base(CBU,cliente,saldo)
        {
            this.interesDescubierto = interesDescubierto;
        }
        public CtaCorriente(ulong CBU, string cliente): base(CBU, cliente)
        {
            this.interesDescubierto = 0;
            setSaldo(0);
        }

        public override bool extraer(float monto)
        {
            if (monto <= getSaldo())
            {
                setSaldo(getSaldo() - monto);
                return true;
            }
            else
            {
                float saldoDescubierto =-1* (getSaldo() - monto);
                if (saldoDescubierto < montoDescubierto)
                {
                    setSaldo(getSaldo() - monto);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public override bool depositar(float monto)
        {
            if (monto > 0)
            {
                if (getSaldo() < 0)
                {
                    Console.WriteLine("Interes descubierto " + interesDescubierto);
                    float montoSinInteres = monto - monto * interesDescubierto;
                    Console.WriteLine("Monto sin interes" + montoSinInteres);
                    setSaldo(getSaldo()+ montoSinInteres);
                    return true;
                }
                else
                {
                    setSaldo(getSaldo() + monto);
                    return true;
                }
            }
            return false;
        }

        public override string darDatos()
        {
            return "Tipo de cuenta: Cuenta Corriente" + base.darDatos() + " Interes en descuebierto: " + CajaAhorro.getInteres().ToString();
        }


    }
}
