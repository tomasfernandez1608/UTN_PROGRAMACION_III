﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using App_bancariaBien;

namespace CuentaBancaria
{
    class Program
    {
       public static List<Cuenta> listaCuentas = new List<Cuenta>();
        static void Main(string[] args)
        {
            
            mostrarMensaje("Inicio de ingreso de datos para cuentas");
            float saldo, monto, interesDescubierto;
            ulong CBU, tarjetaVinculada;
            string cliente, planCuenta;
            int opcion;
            CtaCorriente.MontoDescubierto = devolverFloat("Ingrese el monto maximo descubierto de las cuentas corrientes");
            CajaAhorro.setInteres (devolverFloat("Ingrese el monto de interes para las cajas de ahorro"));
            CBU = devolverULong("Ingrese un CBU, 0 para finalizar");
            while (CBU != 0)
            {
                cliente = leerString("Ingrese el nombre de cliente");
                saldo = devolverFloat("Ingrese el saldo del cliente");
                mostrarMensaje("1 - Cuenta Corriente");
                mostrarMensaje("2 - Caja de Ahorro");
                opcion = devolverInt("ingrese una opcion: ");
                if (opcion == 1)
                {
                    interesDescubierto = devolverFloat("Ingrese el interes descubierto de la cuenta");
                    listaCuentas.Add(new CtaCorriente(interesDescubierto, CBU,cliente,saldo));
                }
                if(opcion == 2)
                {
                    planCuenta = leerString("Ïngrese el plan de la cuenta");
                    tarjetaVinculada = devolverULong("Ingrese la tarjeta vinculada");
                    listaCuentas.Add(new CajaAhorro(planCuenta,tarjetaVinculada,CBU,cliente,saldo));

                }
                CBU = devolverULong("Ingrese un CBU, 0 para finalizar");
            }
            mostrarMensaje("Ingreso de datos finalizado.");
            CBU = devolverULong("Ingrese un CBU para buscar. 0 para finalizar");
            while(CBU != 0) { 
            Cuenta cuenta = buscar(CBU);
            if (cuenta!=null)
            {
                if(cuenta is CtaCorriente)
                {
                    CtaCorriente ctaCorriente = (CtaCorriente)cuenta;
                        Console.WriteLine(ctaCorriente.darDatos());
                        monto = devolverFloat("Ingrese un monto a depositar");
                    ctaCorriente.depositar(monto);
                    monto = devolverFloat("Ingrese un monto a extraer");
                    ctaCorriente.extraer(monto);
                    Console.WriteLine(ctaCorriente.darDatos());
                }
                    else
                    {
                        if(cuenta is CajaAhorro)
                        {
                            CajaAhorro caja = (CajaAhorro)cuenta;
                            Console.WriteLine(caja.darDatos());
                            monto = devolverFloat("Ingrese un monto a depositar");
                            caja.depositar(monto);
                            monto = devolverFloat("Ingrese un monto a extraer");
                            caja.extraer(monto);
                           Console.WriteLine( caja.darDatos());
                        }
                    }
            }
                else
                {
                    mostrarMensaje("Cuenta no encontrada");
                }
                CBU = devolverULong("Ingrese un CBU para buscar. 0 para finalizar");
            }
            foreach(Cuenta cta in listaCuentas)
            {
                if(cta is CajaAhorro)
                {
                    CajaAhorro caja = (CajaAhorro)cta;
                    Console.WriteLine(caja.darDatos());
                }
                if(cta is CtaCorriente)
                {
                    CtaCorriente ctaCorriente = (CtaCorriente)cta;
                    Console.WriteLine(ctaCorriente.darDatos());
                }
            }
            Console.ReadKey();


        }
        public static ulong devolverULong(string mensaje)
        {
            string rta = leerString(mensaje);
            return ulong.Parse(rta);
        }
        public static float devolverFloat(string mensaje)
        {
            string rta = leerString(mensaje);
            return float.Parse(rta);

        }
        public static int devolverInt(string mensaje)
        {
            string rta = leerString(mensaje);
            return int.Parse(rta);
        }
        public static string leerString(string mensaje)
        {
            Console.WriteLine(mensaje);
            return Console.ReadLine();
        }

        public static void mostrarMensaje(string mensaje)
        {
            Console.WriteLine(mensaje);
        }
        public static Cuenta buscar(ulong CBU)
        {
            Cuenta cuenta = new Cuenta(CBU, "");
            int indice = listaCuentas.IndexOf(cuenta);
            if (indice >= 0)
            {
                return listaCuentas[indice];
            }
            else
            {
                return null;
            }
        }

    }
}
